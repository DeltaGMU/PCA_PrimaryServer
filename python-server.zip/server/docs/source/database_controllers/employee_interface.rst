Employee Interface
===========================

.. automodule:: server.lib.database_controllers.employee_interface
    :members:
    :undoc-members:
    :show-inheritance:
