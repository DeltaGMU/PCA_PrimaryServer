Student Interface
===========================

.. automodule:: server.lib.database_controllers.student_interface
    :members:
    :undoc-members:
    :show-inheritance:
