Employee Hours Interface
===========================

.. automodule:: server.lib.database_controllers.employee_hours_interface
    :members:
    :undoc-members:
    :show-inheritance:
