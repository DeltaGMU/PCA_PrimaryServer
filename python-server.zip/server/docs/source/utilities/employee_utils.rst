Employee Utility
===================

.. automodule:: server.lib.utils.employee_utils
   :members:
   :undoc-members:
   :show-inheritance:
