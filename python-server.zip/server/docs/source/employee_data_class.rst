Employee Data Class
========================

.. automodule:: server.lib.data_models.employee
    :members:
    :undoc-members:
    :show-inheritance:
