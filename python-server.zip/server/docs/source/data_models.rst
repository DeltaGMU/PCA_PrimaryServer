Data Class Modules
=====================

.. toctree::
   :maxdepth: 2
   :caption: Data Model Class Modules

   data_models/employee_data_class
   data_models/employee_contact_info_data_class
   data_models/employee_hours_data_class
   data_models/employee_role_data_class
   data_models/student_data_class
   data_models/student_contact_info_data_class
   data_models/student_care_hours_data_class
   data_models/student_grade_data_class
   data_models/report_data_class
   data_models/access_token_data_class
   data_models/reset_token_data_class
