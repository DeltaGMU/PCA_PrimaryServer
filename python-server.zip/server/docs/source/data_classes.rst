Data Class Modules
=====================

.. toctree::
   :maxdepth: 2
   :caption: Data Class Modules

   employee_data_class
   student_data_class
