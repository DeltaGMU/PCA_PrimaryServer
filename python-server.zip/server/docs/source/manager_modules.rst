Manager Modules
=================

.. toctree::
   :maxdepth: 2
   :caption: Manager Modules

   managers/config_manager
   managers/database_manager
   managers/web_manager
   managers/logging_manager
