API - Reports Routing
==============================

.. automodule:: server.web_api.routing.v1.reports_routing
    :members:
    :undoc-members:
    :show-inheritance:
