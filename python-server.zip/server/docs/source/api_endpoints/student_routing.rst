API - Student Routing
==============================

.. automodule:: server.web_api.routing.v1.student_routing
    :members:
    :undoc-members:
    :show-inheritance:
