API - Student Care Service Routing
=====================================

.. automodule:: server.web_api.routing.v1.student_care_routing
    :members:
    :undoc-members:
    :show-inheritance:
