API - Employee Timesheets Routing
===================================

.. automodule:: server.web_api.routing.v1.employee_hours_routing
    :members:
    :undoc-members:
    :show-inheritance:
