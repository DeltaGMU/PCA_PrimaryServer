API - Core Routing
==============================

.. automodule:: server.web_api.routing.v1.core_routing
    :members:
    :undoc-members:
    :show-inheritance:
