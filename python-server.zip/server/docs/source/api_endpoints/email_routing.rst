API - Email Routing
==============================

.. automodule:: server.web_api.routing.v1.email_routing
    :members:
    :undoc-members:
    :show-inheritance:
