API - Employee Routing
==============================

.. automodule:: server.web_api.routing.v1.employee_routing
    :members:
    :undoc-members:
    :show-inheritance:
