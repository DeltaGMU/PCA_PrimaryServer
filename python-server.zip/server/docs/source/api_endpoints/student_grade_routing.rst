API - Student Grade Routing
================================

.. automodule:: server.web_api.routing.v1.student_grade_routing
    :members:
    :undoc-members:
    :show-inheritance:
