Student Data Class
========================

.. automodule:: server.lib.data_models.student
    :members:
    :undoc-members:
    :show-inheritance:
