Web API Routes Module
==========================

.. automodule:: server.web_api.api_routes
   :members:
   :undoc-members:
   :show-inheritance:

