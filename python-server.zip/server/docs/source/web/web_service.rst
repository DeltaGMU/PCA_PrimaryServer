Web Service Module
======================

.. automodule:: server.web_api.web_service
   :members:
   :undoc-members:
   :show-inheritance:

