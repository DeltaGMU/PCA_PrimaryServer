API Routing Modules
==============================

.. toctree::
   :maxdepth: 2
   :caption: Web Modules

   api_endpoints/core_routing
   api_endpoints/employee_routing
   api_endpoints/employee_hours_routing
   api_endpoints/student_routing
   api_endpoints/student_care_routing
   api_endpoints/student_grade_routing
   api_endpoints/reports_routing
   api_endpoints/email_routing