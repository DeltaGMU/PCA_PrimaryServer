API Response Models
======================

This page highlights the different types of response models that are available
for the API server to use when responding to HTTP requests from a web interface.

.. automodule:: server.web_api.models
   :members:
   :undoc-members:
   :show-inheritance:
