Project Resources and Constants
==================================

.. toctree::
   :maxdepth: 2
   :caption: Project Resources and Constants:

   error_codes
   strings
