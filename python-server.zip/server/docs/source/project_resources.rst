Project Resources and Constants
==================================

.. toctree::
   :maxdepth: 2
   :caption: Project Resources and Constants:

   constants/error_codes
   constants/strings
