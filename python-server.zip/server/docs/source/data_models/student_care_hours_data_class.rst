Student Care Hours Data Class
==================================

.. automodule:: server.lib.data_models.student_care_hours
    :members:
    :show-inheritance: