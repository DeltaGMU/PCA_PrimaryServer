Student Contact Info Data Class
====================================

.. automodule:: server.lib.data_models.student_contact_info
    :members:
    :show-inheritance: