Report Data Class
============================

.. automodule:: server.lib.data_models.report
    :members:
    :show-inheritance: