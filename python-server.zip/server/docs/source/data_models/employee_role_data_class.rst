Employee Role Data Class
============================

.. automodule:: server.lib.data_models.employee_role
    :members:
    :show-inheritance: