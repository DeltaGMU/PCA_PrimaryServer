Employee Contact Information Data Class
===========================================

.. automodule:: server.lib.data_models.employee_contact_info
    :members:
    :show-inheritance: