Access Token Data Class
===========================

.. automodule:: server.lib.data_models.access_token
    :members:
    :show-inheritance:
