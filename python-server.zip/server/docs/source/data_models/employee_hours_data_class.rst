Employee Hours Data Class
============================

.. automodule:: server.lib.data_models.employee_hours
    :members:
    :show-inheritance: