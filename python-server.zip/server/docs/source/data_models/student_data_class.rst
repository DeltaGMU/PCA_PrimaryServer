Student Data Class
===========================

.. automodule:: server.lib.data_models.student
    :members:
    :show-inheritance: