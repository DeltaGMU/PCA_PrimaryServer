# PCA_PrimaryServer
This repository contains the source code for Team Delta's PCA Python Processing Server.
This is an integral part of the back-end architecture and will be used to host a REST API and integrate between the MariaDB database server and the Web Interface server.
